#Code by Andrew Howe and John Manoli

import numpy

from FileIO import FileIO

from TemperatureData import TemperatureData

from Date import Date

import matplotlib.pyplot as pyplot

f = FileIO()

t = TemperatureData()

d = Date()

class Chart:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def drawLineChart(self):
        
        fig = pyplot.figure()
        pyplot.title('')
        pyplot.ylabel('')
        pyplot.xlabel(" ")

        pyplot.plot(self.x, self.y, marker='o')  
        pyplot.show()

def main():

    x = []
    #for i in range (12):
        #min.append(t.minTemperature[i])
    y = []
    #for i in range (12):
        #x.append(d.month[i])
    c = Chart(x, y)
    c.drawLineChart()

if __name__ == "__main__":
    main()